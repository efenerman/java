
package Musicly;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;



public class Database {
   String url = "jdbc:mysql://localhost:3306/musics?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey";
    String user = "root";
    String password = "12345678";
    private ResultSet rs;

    public Connection connect() {
        Connection connection;
        try {
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            connection = null;
        }
        return connection;
    }
  public void disConnection(){
      Connection disConnection = null;
      try{
          disConnection.close();
      }catch(SQLException e){
          e.printStackTrace();
      }
  }
public ArrayList<String> getSongname() throws SQLException{
    ArrayList<String> songname=new ArrayList<>();
    Connection c=connect();
     Statement statement=c.createStatement();
     String s ="SELECT * FROM song;";
     rs=statement.executeQuery(s);
     while(rs.next()){
         songname.add(rs.getString("SongName"));
         
     }
     return songname;
}
public ArrayList<String> getSongType() throws SQLException{
    ArrayList<String> songtype =new ArrayList<>();
    Connection c=connect();
     Statement statement=c.createStatement();
     String s ="SELECT * FROM song ;";
     rs=statement.executeQuery(s);
     while(rs.next()){
         songtype.add(rs.getString("SongType"));
     }
     return songtype;
}
public ArrayList<String> getArtist() throws SQLException{
    ArrayList<String> artist=new ArrayList<>();
    Connection c=connect();
     Statement statement=c.createStatement();
     String s ="SELECT * FROM song;";
     rs=statement.executeQuery(s);
     while(rs.next()){
         artist.add(rs.getString("Artist"));
        
         
     }
     return artist;
}
public String getPath(DefaultListModel dlm)
    {
        
        String path = null;
        
        Connection connection = connect();
        try (PreparedStatement ps = connection.prepareStatement(
                    "SELECT SongPath " + "FROM song where songID=")) 
        {
            ResultSet res = ps.executeQuery();
            while (res.next())
            {
              dlm.addElement(res.getString(1));
              
            }	
        }
        catch (SQLException ex) {
            System.err.println("An error has occured." + ex.getMessage());
        }
        return path;
    }


   
public ArrayList<Integer> getID() throws SQLException{
 ArrayList<Integer> ids=new ArrayList<>();
 Connection c=connect();
Statement statement=c.createStatement();
String s="SELECT * FROM song";
rs=statement.executeQuery(s);
while(rs.next()){
    ids.add(rs.getInt("songID"));
}
return ids;
       
   }










public boolean saveUser(User c) throws SQLException{
    
    try{
        Connection connection=connect();
        String s = "insert into customer(username,password) values(?,?)";
        try (PreparedStatement ps = connection.prepareStatement(s)) {
            ps.setString(1, c.getKullanici_adi());
            ps.setString(2, c.getParola());
            ps.executeUpdate();
            ps.close();
           disConnection();
            return true;
        }
       
      
       
       
        
    }catch(SQLException e){
        return false;
    }
}
public boolean deleteUser(User u) throws SQLException{
    try{
        Connection connection=connect();
        String s ="delete from customer where username=? and password=?";
        PreparedStatement ps = connection.prepareStatement(s);
        ps.setString(1,u.getKullanici_adi());
        ps.setString(2,u.getParola());
         ps.executeUpdate();
         ps.close();
         disConnection();
         return true;
    }
    catch(SQLException e){
        return false;
        
    }
    
}
public boolean deleteSong(song s)throws SQLException{
   try{
    Connection connection=connect();
    String sql="delete from song where SongName=?";
    PreparedStatement ps=connection.prepareStatement(sql);
    ps.setString(1, s.getSongName());
    ps.executeUpdate();
    ps.close();
    disConnection();
    return true;
   }catch(SQLException e){
       return false;
   }
}
public boolean addSong(song s) throws SQLException{
    try{
        Connection connection=connect();
        String sql="insert into song(SongName,SongType,Artist,SongPath,songID) values(?,?,?,?,?)";
        PreparedStatement ps=connection.prepareStatement(sql);
        ps.setString(1, s.getSongName());
        ps.setString(2, s.getSongType());
        ps.setString(3, s.getArtist());
        ps.setString(4, s.getSongPath());
        ps.setInt(5, s.getSongID());
        ps.executeUpdate();
        ps.close();
        disConnection();
        return true;
    }catch(SQLException e){
        return false;
        
        
    }
}

 public   String PlaySelectedSong(int songName) throws SQLException {
    Connection connection=connect();
 
    String sql="select SongPath from song where songID="+songName+";";
    PreparedStatement ps=connection.prepareStatement(sql);

    Statement st = connection.createStatement();    
    rs=st.executeQuery(sql);
    String name="";
    while(rs.next()){
        name = rs.getString(1);

    }
    return name;
    }

public  boolean login(String kullanici_adi, String parola) {
       Connection connection=connect();
        String sql="Select * From customer where username= ? and password = ?";
       try {
           PreparedStatement ps=connection.prepareStatement(sql);
           ps.setString(1, kullanici_adi);
           ps.setString(2, parola);
           rs=ps.executeQuery();
          return rs.next();
       } catch (SQLException ex) {
           Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
       }
      return false;
        
    }
  


}
    
